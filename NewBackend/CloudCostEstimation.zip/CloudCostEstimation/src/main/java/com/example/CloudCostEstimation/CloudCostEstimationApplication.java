package com.example.CloudCostEstimation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudCostEstimationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudCostEstimationApplication.class, args);
	}

}
