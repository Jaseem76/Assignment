package com.example.CloudCostEstimation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudCostEstimationApplicationTests {

	@Test
	void contextLoads() {
	}

}
